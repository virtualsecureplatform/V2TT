#include <tfhe/tfhe.h>
#include <tfhe/tfhe_io.h>
#include <stdio.h>
#include <iostream>
#include <cstring>
#include <chrono>

int main(int argc, char *argv[]) {
    int number_of_clock;
    if(argc == 1){
        number_of_clock = 0;
    }else{
        number_of_clock = std::atoi(argv[1]);
    }

    std::chrono::system_clock::time_point start, end; 
    start = std::chrono::system_clock::now();

    //reads the cloud key from file
    FILE* cloud_key = fopen("cloud.key","rb");
    TFheGateBootstrappingCloudKeySet* bk = new_tfheGateBootstrappingCloudKeySet_fromFile(cloud_key);
    fclose(cloud_key);
 
    //if necessary, the params are inside the key
    const TFheGateBootstrappingParameterSet* params = bk->params;

    //read the 2x16 ciphertexts
    LweSample* cipherin = new_gate_bootstrapping_ciphertext_array(18, params);
    LweSample* cipherout = new_gate_bootstrapping_ciphertext_array(8, params);
    LweSample* cipherwire = new_gate_bootstrapping_ciphertext_array(29, params);

    //reads the 2x16 ciphertexts from the cloud file
    FILE* cloud_data = fopen("cloud.data","rb");
    for (int i=0; i<18; i++) import_gate_bootstrapping_ciphertext_fromFile(cloud_data, &cipherin[i], params);
    fclose(cloud_data);

    //do operations described as circuit:
    for(int clock = 0; clock < number_of_clock + 1; clock++){
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsANDYN(&cipherwire[10],&cipherin[10],&cipherin[2],bk);
        #pragma omp section
        bootsANDYN(&cipherwire[9],&cipherin[10],&cipherin[3],bk);
        #pragma omp section
        bootsORYN(&cipherwire[8],&cipherin[4],&cipherin[10],bk);
        #pragma omp section
        bootsANDYN(&cipherwire[7],&cipherin[10],&cipherin[5],bk);
        #pragma omp section
        bootsORYN(&cipherwire[6],&cipherin[6],&cipherin[10],bk);
        #pragma omp section
        bootsORYN(&cipherwire[4],&cipherin[7],&cipherin[10],bk);
        #pragma omp section
        bootsORYN(&cipherwire[3],&cipherin[8],&cipherin[10],bk);
        #pragma omp section
        bootsANDYN(&cipherwire[1],&cipherin[10],&cipherin[9],bk);
        #pragma omp section
        bootsANDYN(&cipherwire[2],&cipherin[9],&cipherin[10],bk);
        #pragma omp section
        bootsORYN(&cipherwire[5],&cipherin[9],&cipherin[12],bk);
        #pragma omp section
        bootsNOR(&cipherwire[0],&cipherin[16],&cipherin[17],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[13],&cipherin[9],&cipherwire[3],bk);
        #pragma omp section
        bootsNOR(&cipherwire[12],&cipherin[11],&cipherwire[1],bk);
        #pragma omp section
        bootsNAND(&cipherwire[14],&cipherin[11],&cipherwire[10],bk);
        #pragma omp section
        bootsOR(&cipherwire[15],&cipherin[11],&cipherwire[10],bk);
        #pragma omp section
        bootsANDYN(&cipherwire[11],&cipherwire[0],&cipherin[15],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[10],&cipherin[11],&cipherwire[13],bk);
        #pragma omp section
        bootsANDYN(&cipherwire[1],&cipherwire[11],&cipherin[14],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsANDYN(&cipherwire[13],&cipherwire[1],&cipherin[13],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsANDYN(&cipherwire[16],&cipherwire[13],&cipherin[12],bk);
        #pragma omp section
        bootsAND(&cipherwire[17],&cipherwire[13],&cipherwire[5],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherwire[5],&cipherwire[16],&cipherwire[10],bk);
        #pragma omp section
        bootsAND(&cipherout[7],&cipherwire[16],&cipherwire[12],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsORYN(&cipherwire[16],&cipherout[7],&cipherin[9],bk);
        #pragma omp section
        bootsNAND(&cipherwire[18],&cipherin[10],&cipherwire[5],bk);
        #pragma omp section
        bootsNAND(&cipherwire[10],&cipherout[7],&cipherwire[2],bk);
        #pragma omp section
        bootsORYN(&cipherwire[13],&cipherwire[12],&cipherwire[5],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherwire[19],&cipherin[8],&cipherwire[18],bk);
        #pragma omp section
        bootsORYN(&cipherwire[20],&cipherwire[3],&cipherwire[16],bk);
        #pragma omp section
        bootsORYN(&cipherwire[12],&cipherwire[2],&cipherwire[16],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsORYN(&cipherwire[3],&cipherin[11],&cipherwire[19],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[16],&cipherin[11],&cipherwire[19],bk);
        #pragma omp section
        bootsAND(&cipherout[6],&cipherwire[5],&cipherwire[20],bk);
        #pragma omp section
        bootsAND(&cipherwire[2],&cipherwire[13],&cipherwire[12],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsORYN(&cipherwire[12],&cipherin[12],&cipherwire[2],bk);
        #pragma omp section
        bootsNAND(&cipherwire[5],&cipherwire[16],&cipherwire[4],bk);
        #pragma omp section
        bootsXOR(&cipherwire[13],&cipherwire[16],&cipherwire[4],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherwire[4],&cipherwire[3],&cipherwire[12],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[3],&cipherwire[5],&cipherwire[4],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherout[5],&cipherwire[3],&cipherwire[17],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherwire[5],&cipherin[10],&cipherout[5],bk);
        #pragma omp section
        bootsMUX(&cipherwire[4],&cipherout[5],&cipherwire[13],&cipherwire[19],bk);
        #pragma omp section
        bootsANDYN(&cipherwire[3],&cipherwire[2],&cipherout[5],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsXNOR(&cipherwire[13],&cipherin[7],&cipherwire[5],bk);
        #pragma omp section
        bootsORYN(&cipherwire[2],&cipherin[12],&cipherwire[4],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[12],&cipherin[12],&cipherwire[4],bk);
        #pragma omp section
        bootsANDYN(&cipherwire[16],&cipherwire[10],&cipherwire[3],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsOR(&cipherwire[5],&cipherin[11],&cipherwire[13],bk);
        #pragma omp section
        bootsNAND(&cipherwire[17],&cipherin[11],&cipherwire[13],bk);
        #pragma omp section
        bootsOR(&cipherwire[18],&cipherin[13],&cipherwire[16],bk);
        #pragma omp section
        bootsNAND(&cipherwire[19],&cipherin[13],&cipherwire[16],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[16],&cipherwire[17],&cipherwire[6],bk);
        #pragma omp section
        bootsAND(&cipherwire[20],&cipherwire[2],&cipherwire[18],bk);
        #pragma omp section
        bootsAND(&cipherwire[21],&cipherwire[1],&cipherwire[19],bk);
        #pragma omp section
        bootsNAND(&cipherwire[22],&cipherwire[5],&cipherwire[17],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsXOR(&cipherwire[2],&cipherwire[6],&cipherwire[22],bk);
        #pragma omp section
        bootsNAND(&cipherwire[1],&cipherwire[5],&cipherwire[16],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[5],&cipherwire[12],&cipherwire[1],bk);
        #pragma omp section
        bootsXOR(&cipherwire[6],&cipherwire[12],&cipherwire[1],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[1],&cipherwire[5],&cipherwire[20],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherout[4],&cipherwire[1],&cipherwire[21],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherwire[16],&cipherin[10],&cipherout[4],bk);
        #pragma omp section
        bootsMUX(&cipherwire[12],&cipherout[4],&cipherwire[2],&cipherwire[13],bk);
        #pragma omp section
        bootsMUX(&cipherwire[5],&cipherout[4],&cipherwire[6],&cipherwire[4],bk);
        #pragma omp section
        bootsORYN(&cipherwire[1],&cipherout[4],&cipherwire[3],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsXNOR(&cipherwire[18],&cipherin[6],&cipherwire[16],bk);
        #pragma omp section
        bootsOR(&cipherwire[13],&cipherin[12],&cipherwire[12],bk);
        #pragma omp section
        bootsNAND(&cipherwire[17],&cipherin[12],&cipherwire[12],bk);
        #pragma omp section
        bootsORYN(&cipherwire[4],&cipherin[13],&cipherwire[5],bk);
        #pragma omp section
        bootsXOR(&cipherwire[6],&cipherin[13],&cipherwire[5],bk);
        #pragma omp section
        bootsAND(&cipherwire[2],&cipherwire[10],&cipherwire[1],bk);
        #pragma omp section
        bootsNOT(&cipherwire[3],&cipherwire[5],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsOR(&cipherwire[5],&cipherin[11],&cipherwire[18],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[16],&cipherin[11],&cipherwire[18],bk);
        #pragma omp section
        bootsOR(&cipherwire[19],&cipherin[14],&cipherwire[2],bk);
        #pragma omp section
        bootsNAND(&cipherwire[20],&cipherin[14],&cipherwire[2],bk);
        #pragma omp section
        bootsAND(&cipherwire[21],&cipherwire[13],&cipherwire[17],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsOR(&cipherwire[2],&cipherwire[7],&cipherwire[16],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[24],&cipherwire[7],&cipherwire[16],bk);
        #pragma omp section
        bootsAND(&cipherwire[22],&cipherwire[4],&cipherwire[19],bk);
        #pragma omp section
        bootsAND(&cipherwire[23],&cipherwire[11],&cipherwire[20],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[4],&cipherwire[5],&cipherwire[2],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[2],&cipherwire[17],&cipherwire[4],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[5],&cipherwire[4],&cipherwire[21],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherwire[4],&cipherwire[13],&cipherwire[2],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsOR(&cipherwire[2],&cipherwire[6],&cipherwire[4],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[7],&cipherwire[6],&cipherwire[4],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[4],&cipherwire[2],&cipherwire[22],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherout[3],&cipherwire[4],&cipherwire[23],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherwire[13],&cipherin[10],&cipherout[3],bk);
        #pragma omp section
        bootsMUX(&cipherwire[11],&cipherout[3],&cipherwire[24],&cipherwire[18],bk);
        #pragma omp section
        bootsMUX(&cipherwire[6],&cipherout[3],&cipherwire[5],&cipherwire[12],bk);
        #pragma omp section
        bootsMUX(&cipherwire[4],&cipherout[3],&cipherwire[7],&cipherwire[3],bk);
        #pragma omp section
        bootsOR(&cipherwire[2],&cipherwire[1],&cipherout[3],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsXNOR(&cipherwire[18],&cipherin[5],&cipherwire[13],bk);
        #pragma omp section
        bootsOR(&cipherwire[16],&cipherin[12],&cipherwire[11],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[17],&cipherin[12],&cipherwire[11],bk);
        #pragma omp section
        bootsOR(&cipherwire[7],&cipherin[13],&cipherwire[6],bk);
        #pragma omp section
        bootsNAND(&cipherwire[12],&cipherin[13],&cipherwire[6],bk);
        #pragma omp section
        bootsOR(&cipherwire[3],&cipherin[14],&cipherwire[4],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[5],&cipherin[14],&cipherwire[4],bk);
        #pragma omp section
        bootsAND(&cipherwire[1],&cipherwire[10],&cipherwire[2],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsOR(&cipherwire[2],&cipherin[11],&cipherwire[18],bk);
        #pragma omp section
        bootsNAND(&cipherwire[13],&cipherin[11],&cipherwire[18],bk);
        #pragma omp section
        bootsOR(&cipherwire[19],&cipherin[15],&cipherwire[1],bk);
        #pragma omp section
        bootsNAND(&cipherwire[20],&cipherin[15],&cipherwire[1],bk);
        #pragma omp section
        bootsAND(&cipherwire[21],&cipherwire[7],&cipherwire[12],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[22],&cipherwire[13],&cipherwire[8],bk);
        #pragma omp section
        bootsAND(&cipherwire[23],&cipherwire[3],&cipherwire[19],bk);
        #pragma omp section
        bootsAND(&cipherwire[24],&cipherwire[0],&cipherwire[20],bk);
        #pragma omp section
        bootsNAND(&cipherwire[25],&cipherwire[2],&cipherwire[13],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsXOR(&cipherwire[3],&cipherwire[8],&cipherwire[25],bk);
        #pragma omp section
        bootsAND(&cipherwire[0],&cipherwire[2],&cipherwire[22],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsOR(&cipherwire[2],&cipherwire[17],&cipherwire[0],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[8],&cipherwire[17],&cipherwire[0],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[0],&cipherwire[16],&cipherwire[2],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[2],&cipherwire[12],&cipherwire[0],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[13],&cipherwire[0],&cipherwire[21],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherwire[0],&cipherwire[7],&cipherwire[2],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsOR(&cipherwire[2],&cipherwire[5],&cipherwire[0],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[7],&cipherwire[5],&cipherwire[0],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[0],&cipherwire[2],&cipherwire[23],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherout[2],&cipherwire[0],&cipherwire[24],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherwire[17],&cipherin[10],&cipherout[2],bk);
        #pragma omp section
        bootsMUX(&cipherwire[16],&cipherout[2],&cipherwire[3],&cipherwire[18],bk);
        #pragma omp section
        bootsAND(&cipherwire[0],&cipherwire[10],&cipherout[2],bk);
        #pragma omp section
        bootsMUX(&cipherwire[12],&cipherout[2],&cipherwire[8],&cipherwire[11],bk);
        #pragma omp section
        bootsMUX(&cipherwire[5],&cipherout[2],&cipherwire[13],&cipherwire[6],bk);
        #pragma omp section
        bootsMUX(&cipherwire[2],&cipherout[2],&cipherwire[7],&cipherwire[4],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsXNOR(&cipherwire[20],&cipherin[4],&cipherwire[17],bk);
        #pragma omp section
        bootsOR(&cipherwire[18],&cipherin[12],&cipherwire[16],bk);
        #pragma omp section
        bootsNAND(&cipherwire[19],&cipherin[12],&cipherwire[16],bk);
        #pragma omp section
        bootsOR(&cipherwire[11],&cipherin[13],&cipherwire[12],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[13],&cipherin[13],&cipherwire[12],bk);
        #pragma omp section
        bootsOR(&cipherwire[7],&cipherin[14],&cipherwire[5],bk);
        #pragma omp section
        bootsNAND(&cipherwire[8],&cipherin[14],&cipherwire[5],bk);
        #pragma omp section
        bootsOR(&cipherwire[4],&cipherin[15],&cipherwire[2],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[6],&cipherin[15],&cipherwire[2],bk);
        #pragma omp section
        bootsOR(&cipherwire[3],&cipherwire[1],&cipherwire[0],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsOR(&cipherwire[0],&cipherin[11],&cipherwire[20],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[1],&cipherin[11],&cipherwire[20],bk);
        #pragma omp section
        bootsOR(&cipherwire[17],&cipherin[16],&cipherwire[3],bk);
        #pragma omp section
        bootsAND(&cipherwire[21],&cipherin[16],&cipherwire[3],bk);
        #pragma omp section
        bootsNAND(&cipherwire[22],&cipherin[17],&cipherwire[3],bk);
        #pragma omp section
        bootsAND(&cipherwire[24],&cipherwire[18],&cipherwire[19],bk);
        #pragma omp section
        bootsAND(&cipherwire[23],&cipherwire[7],&cipherwire[8],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNOR(&cipherwire[27],&cipherin[17],&cipherwire[21],bk);
        #pragma omp section
        bootsOR(&cipherwire[25],&cipherwire[9],&cipherwire[1],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[28],&cipherwire[9],&cipherwire[1],bk);
        #pragma omp section
        bootsAND(&cipherwire[26],&cipherwire[4],&cipherwire[17],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[1],&cipherwire[0],&cipherwire[25],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[0],&cipherwire[19],&cipherwire[1],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[4],&cipherwire[1],&cipherwire[24],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherwire[1],&cipherwire[18],&cipherwire[0],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsOR(&cipherwire[0],&cipherwire[13],&cipherwire[1],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[9],&cipherwire[13],&cipherwire[1],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[1],&cipherwire[11],&cipherwire[0],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[0],&cipherwire[8],&cipherwire[1],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[11],&cipherwire[1],&cipherwire[23],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherwire[1],&cipherwire[7],&cipherwire[0],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsOR(&cipherwire[0],&cipherwire[6],&cipherwire[1],bk);
        #pragma omp section
        bootsXNOR(&cipherwire[7],&cipherwire[6],&cipherwire[1],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[1],&cipherwire[0],&cipherwire[26],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherout[1],&cipherwire[1],&cipherwire[27],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[6],&cipherin[10],&cipherout[1],bk);
        #pragma omp section
        bootsMUX(&cipherwire[8],&cipherout[1],&cipherwire[28],&cipherwire[20],bk);
        #pragma omp section
        bootsAND(&cipherwire[0],&cipherwire[10],&cipherout[1],bk);
        #pragma omp section
        bootsMUX(&cipherwire[13],&cipherout[1],&cipherwire[4],&cipherwire[16],bk);
        #pragma omp section
        bootsMUX(&cipherwire[17],&cipherout[1],&cipherwire[9],&cipherwire[12],bk);
        #pragma omp section
        bootsMUX(&cipherwire[1],&cipherout[1],&cipherwire[11],&cipherwire[5],bk);
        #pragma omp section
        bootsMUX(&cipherwire[18],&cipherout[1],&cipherwire[7],&cipherwire[2],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsXNOR(&cipherwire[5],&cipherin[3],&cipherwire[6],bk);
        #pragma omp section
        bootsOR(&cipherwire[7],&cipherin[12],&cipherwire[8],bk);
        #pragma omp section
        bootsNAND(&cipherwire[10],&cipherin[12],&cipherwire[8],bk);
        #pragma omp section
        bootsNAND(&cipherwire[9],&cipherin[13],&cipherwire[13],bk);
        #pragma omp section
        bootsOR(&cipherwire[11],&cipherin[13],&cipherwire[13],bk);
        #pragma omp section
        bootsOR(&cipherwire[12],&cipherin[14],&cipherwire[17],bk);
        #pragma omp section
        bootsNAND(&cipherwire[16],&cipherin[14],&cipherwire[17],bk);
        #pragma omp section
        bootsOR(&cipherwire[4],&cipherin[15],&cipherwire[1],bk);
        #pragma omp section
        bootsNAND(&cipherwire[20],&cipherin[15],&cipherwire[1],bk);
        #pragma omp section
        bootsNAND(&cipherwire[19],&cipherin[16],&cipherwire[18],bk);
        #pragma omp section
        bootsOR(&cipherwire[21],&cipherin[16],&cipherwire[18],bk);
        #pragma omp section
        bootsOR(&cipherwire[2],&cipherwire[3],&cipherwire[0],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsOR(&cipherwire[13],&cipherin[17],&cipherwire[2],bk);
        #pragma omp section
        bootsNAND(&cipherwire[0],&cipherwire[14],&cipherwire[5],bk);
        #pragma omp section
        bootsAND(&cipherwire[1],&cipherwire[7],&cipherwire[15],bk);
        #pragma omp section
        bootsAND(&cipherwire[3],&cipherwire[9],&cipherwire[10],bk);
        #pragma omp section
        bootsAND(&cipherwire[6],&cipherwire[11],&cipherwire[12],bk);
        #pragma omp section
        bootsAND(&cipherwire[8],&cipherwire[16],&cipherwire[20],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherwire[5],&cipherwire[13],&cipherwire[21],bk);
        #pragma omp section
        bootsNAND(&cipherwire[2],&cipherwire[0],&cipherwire[1],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[0],&cipherwire[2],&cipherwire[3],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[1],&cipherwire[0],&cipherwire[6],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[0],&cipherwire[1],&cipherwire[8],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[1],&cipherwire[4],&cipherwire[0],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[0],&cipherwire[19],&cipherwire[1],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsNAND(&cipherwire[1],&cipherwire[0],&cipherwire[5],bk);    
        }
        #pragma omp parallel sections
        {
        #pragma omp section
        bootsAND(&cipherout[0],&cipherwire[22],&cipherwire[1],bk);    
        }
        
        #pragma omp parallel sections
        {
        }
    }
    
    //Copy input ports' data to output ports when they are directly conneted.

    //export the 8 ciphertexts to a file (for the cloud)
    FILE* answer_data = fopen("answer.data","wb");
    for (int i=0; i<8; i++) export_gate_bootstrapping_ciphertext_toFile(answer_data, &cipherout[i], params);
    fclose(answer_data);

    //clean up all pointers
    delete_gate_bootstrapping_ciphertext_array(18, cipherin);
    delete_gate_bootstrapping_ciphertext_array(8, cipherout);
    delete_gate_bootstrapping_ciphertext_array(29, cipherwire);
    delete_gate_bootstrapping_cloud_keyset(bk);
    end = std::chrono::system_clock::now();
    double time = static_cast<double>(std::chrono::duration_cast<std::chrono::microseconds>(end - start).count() / 1000.0);
    printf("cloud time %lf[ms]\n", time);
}